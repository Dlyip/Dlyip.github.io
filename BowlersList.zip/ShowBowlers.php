<!DOCTYPE html>
<html>
<head>
    <title> Show Guest Book </title>
</head>
<body>
<pre>
<?php
echo readfile("Bowlers.txt");
?>
</pre>
</body>
</html>
