<!DOCTYPE html>
<html>
<head>
    <title> Sign Bowlers </title>
</head>
<body>
<?php
if (empty($_POST['name']) || empty($_POST['age']) || empty($_POST['average']))
    echo "<p> You must enter your name, age, and bowling average.
        Click your browser's Back button to return to the Bowlers' List. </p>\n";
else{
    $Name = addslashes($_POST['name']);
    $Age = addslashes($_POST['age']);
    $Average = addslashes($_POST['average']);
    $BowlersList = fopen("Bowlers.txt", "ab");
    if (is_writeable("Bowlers.txt")){
        if (fwrite($BowlersList, $Name . " , " . $Age . " , " . $Average . "\n"))
            echo "<p> Thank you for registering for our bowling list! </p>";
        else
            echo "<p> Error in inputting your information.</p>";
        }
    else
        echo "<p> Cannot write to the file. </p>\n";
    fclose($BowlersList);
}
?>
</body>
</html>
