<!DOCTYPE html>
<html>
<head>
    <title>Jumble Maker</title>
</head>
<body>
<?php
function displayError($fieldName, $errorMsg){
    echo "There is an error in $fieldName: ". $errorMsg ."<br>";
}
function validateWord($data, $fieldName){
    global $errorCount;
    if (empty($data) == false) {
        if (strlen($data) >= 4 && strlen($data) <= 7) {
            if (ctype_alpha($data) == true) {
                $data = strtoupper($data);
                $data = str_shuffle($data);
            } else {
                $errorMsg = "This string contains characters other than letters.";
                displayError($fieldName, $errorMsg);
                $errorCount++;
            }
        } else {
            $errorMsg = "This string contains either more than 7 or less than 4 letters.";
            displayError($fieldName, $errorMsg);
            $errorCount++;
        }
    }else {
        $errorMsg = "This string is empty.";
        displayError($fieldName, $errorMsg);
        $errorCount++;
    }
return $data;
}

$errorCount = 0;

$words = array();

$words[] = validateWord($_POST['Word1'], "Word 1");

$words[] = validateWord($_POST['Word2'], "Word 2");

$words[] = validateWord($_POST['Word3'], "Word 3");

$words[] = validateWord($_POST['Word4'], "Word 4");

if ($errorCount>0) {

    echo "Please use the \"Back\" button to re-enter the data.<br />\n";
}

else {

    $wordnum = 0;

    foreach ($words as $word){

        echo "Word ".++$wordnum.": ".$word."<br> \n";

    }
}
?>
</body>
</html>