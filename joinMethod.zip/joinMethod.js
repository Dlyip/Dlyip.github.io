function joinMethod(array) {
    let joined = "";  //Initialize array
    var i; // Create counting variable
    // For loop for adding "and" to each name.
    for (i = 0; i < array.length - 1; i++) {
        joined += array[i] + " and "; //
    }
    // Final Runthrough
    joined += array[array.length-1] + " ";
    // Print document.
    document.write(joined);
}